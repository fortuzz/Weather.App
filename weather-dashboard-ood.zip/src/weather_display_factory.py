# weather_display_factory.py
class WeatherDisplayFactory:
    @staticmethod
    def create_display(self, display_type):
        # Create and return appropriate WeatherDisplay instance
        pass
