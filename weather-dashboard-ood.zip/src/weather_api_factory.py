# weather_api_factory.py

class WeatherAPIFactory:
    @staticmethod
    def create_api(api_type):
        return None
